from motorbit import MotorBit
from pca9685 import PCA9685
import time

motorbit = MotorBit()

motorbit.pca9685.frequency_hz = 50

# Motorbit's A01 is equivalent to PCA9685's LED0
# Motorbit's A02 is equivalent to PCA9685's LED1
# Motorbit's A03 is equivalent to PCA9685's LED2
# Motorbit's A04 is equivalent to PCA9685's LED3

# Motorbit's B01 is equivalent to PCA9685's LED4
# Motorbit's B02 is equivalent to PCA9685's LED5
# Motorbit's B03 is equivalent to PCA9685's LED6
# Motorbit's B04 is equivalent to PCA9685's LED7

# Motorbit's S1 is equivalent to PCA9685's LED8
# Motorbit's S2 is equivalent to PCA9685's LED9
# Motorbit's S3 is equivalent to PCA9685's LED10
# Motorbit's S4 is equivalent to PCA9685's LED11
# Motorbit's S5 is equivalent to PCA9685's LED12
# Motorbit's S6 is equivalent to PCA9685's LED13
# Motorbit's S7 is equivalent to PCA9685's LED14
# Motorbit's S8 is equivalent to PCA9685's LED15
# example: motorbit.pca9685.duty(MotorBit.S1, 4095) is equivalent to motorbit.pca9685.duty(PCA9685.LED8, 4095)

# duty range is 0 ~ 4095 (0% ~ 100%)

motorbit.pca9685.duty(MotorBit.S1, 4095)  # 100%
motorbit.pca9685.duty(MotorBit.S2, 2048)  # 50%
motorbit.pca9685.duty(MotorBit.S3, 1024)  # 25%
motorbit.pca9685.duty(MotorBit.S4, 0)  # 0%
motorbit.pca9685.duty(MotorBit.S5, 4095)  # 100%
motorbit.pca9685.duty(MotorBit.S6, 2048)  # 50%
motorbit.pca9685.duty(MotorBit.S7, 1024)  # 25%
motorbit.pca9685.duty(MotorBit.S8, 0)  # 0%

motorbit.pca9685.duty(MotorBit.A01, 4095)  # 100%
motorbit.pca9685.duty(MotorBit.A02, 2048)  # 50%
motorbit.pca9685.duty(MotorBit.A03, 1024)  # 25%
motorbit.pca9685.duty(MotorBit.A04, 0)  # 0%

motorbit.pca9685.duty(MotorBit.B01, 4095)  # 100%
motorbit.pca9685.duty(MotorBit.B02, 2048)  # 50%
motorbit.pca9685.duty(MotorBit.B03, 1024)  # 25%
motorbit.pca9685.duty(MotorBit.B04, 0)  # 0%
