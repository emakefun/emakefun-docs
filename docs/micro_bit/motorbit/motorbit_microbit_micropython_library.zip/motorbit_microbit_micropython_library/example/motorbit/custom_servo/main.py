from motorbit import MotorBit
import time

motorbit = MotorBit()

motorbit.pca9685.frequency_hz = 50
print('frequency:', motorbit.pca9685.frequency_hz, 'hz')

# 自定义舵机参数
# 普通通用的舵机如sg90最大角度为180度，0度对应的脉冲宽度为0.5ms(500us)，180度对应的脉冲宽度为2.5ms(2500us)
# 例如某款舵机的最大角度为270度，0度对应的脉冲宽度为0.6ms(600us)，270度对应的脉冲宽度为2.4ms(2400us)

# Custom Servo Parameters
# For common standard servos like SG90, the maximum angle is 180 degrees,
# with 0 degrees corresponding to a pulse width of 0.5ms (500us) and 180 degrees corresponding to a pulse width of 2.5ms (2500us).
# For example, for a certain servo with a maximum angle of 270 degrees,
# 0 degrees corresponds to a pulse width of 0.6ms (600us) and 270 degrees corresponds to a pulse width of 2.4ms (2400us).

# SG90
servo_s1 = motorbit.servo(MotorBit.S1)
servo_s1.max_rotation_angle = 180  # S1 maximum angle is 180 degrees
servo_s1.min_pulse_width_us = 500  # S1 min pulse width is 0.5 ms (500 us)
servo_s1.max_pulse_width_us = 2500  # S1 max pulse width is 2.5 ms (2500 us)

# GeekServo(max angle is 270)
servo_s2 = motorbit.servo(MotorBit.S2)
servo_s2.max_rotation_angle = 270  # S2 maximum angle is 270 degrees
servo_s2.min_pulse_width_us = 600  # S2 min pulse width is 0.6 ms (600 us)
servo_s2.max_pulse_width_us = 2400  # S1 max pulse width is 2.4 ms (2400 us)

while True:
    angle = 0
    servo_s1.angle = angle
    servo_s2.angle = angle
    print('angle:', angle)
    time.sleep(1)

    angle = 90
    servo_s1.angle = angle
    servo_s2.angle = angle
    print('angle:', angle)
    time.sleep(1)

    angle = 180
    servo_s1.angle = angle
    servo_s2.angle = angle
    print('angle:', angle)
    time.sleep(1)

    angle = 270
    try:
        servo_s1.angle = angle
    except Exception as ex:
        print('S1:', ex)
    servo_s2.angle = angle
    print('angle:', angle)
    time.sleep(1)
