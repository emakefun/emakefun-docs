from motorbit import MotorBit
import time

motorbit = MotorBit()

motorbit.pca9685.frequency_hz = 50

while True:
    angle = 0
    motorbit.servo(MotorBit.S1).angle = angle
    motorbit.servo(MotorBit.S2).angle = angle
    motorbit.servo(MotorBit.S3).angle = angle
    motorbit.servo(MotorBit.S4).angle = angle
    motorbit.servo(MotorBit.S5).angle = angle
    motorbit.servo(MotorBit.S6).angle = angle
    motorbit.servo(MotorBit.S7).angle = angle
    motorbit.servo(MotorBit.S8).angle = angle
    print('angle:', angle)
    time.sleep(1)

    angle = 90
    motorbit.servo(MotorBit.S1).angle = angle
    motorbit.servo(MotorBit.S2).angle = angle
    motorbit.servo(MotorBit.S3).angle = angle
    motorbit.servo(MotorBit.S4).angle = angle
    motorbit.servo(MotorBit.S5).angle = angle
    motorbit.servo(MotorBit.S6).angle = angle
    motorbit.servo(MotorBit.S7).angle = angle
    motorbit.servo(MotorBit.S8).angle = angle
    print('angle:', angle)
    time.sleep(1)

    angle = 180
    motorbit.servo(MotorBit.S1).angle = angle
    motorbit.servo(MotorBit.S2).angle = angle
    motorbit.servo(MotorBit.S3).angle = angle
    motorbit.servo(MotorBit.S4).angle = angle
    motorbit.servo(MotorBit.S5).angle = angle
    motorbit.servo(MotorBit.S6).angle = angle
    motorbit.servo(MotorBit.S7).angle = angle
    motorbit.servo(MotorBit.S8).angle = angle
    print('angle:', angle)
    time.sleep(1)
