from motorbit import MotorBit
import time

motorbit = MotorBit()

motorbit.pca9685.frequency_hz = 50
print('frequency:', motorbit.pca9685.frequency_hz, ' hz')

while True:
    speed = 2048  # speed range is -4095 ~ 4095
    motorbit.dc_motor(MotorBit.M1).speed = speed
    motorbit.dc_motor(MotorBit.M2).speed = speed
    motorbit.dc_motor(MotorBit.M3).speed = speed
    motorbit.dc_motor(MotorBit.M4).speed = speed
    print('dc motor speed:', speed)
    time.sleep(1)

    speed = -2048  # speed range is -4095 ~ 4095
    motorbit.dc_motor(MotorBit.M1).speed = speed
    motorbit.dc_motor(MotorBit.M2).speed = speed
    motorbit.dc_motor(MotorBit.M3).speed = speed
    motorbit.dc_motor(MotorBit.M4).speed = speed
    print('dc motor speed:', speed)
    time.sleep(1)

    speed = 0  # speed range is -4095 ~ 4095
    motorbit.dc_motor(MotorBit.M1).speed = speed
    motorbit.dc_motor(MotorBit.M2).speed = speed
    motorbit.dc_motor(MotorBit.M3).speed = speed
    motorbit.dc_motor(MotorBit.M4).speed = speed
    print('dc motor speed:', speed)
    time.sleep(1)
