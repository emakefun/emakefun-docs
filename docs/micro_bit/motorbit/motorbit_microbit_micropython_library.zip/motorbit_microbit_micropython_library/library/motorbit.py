from pca9685 import PCA9685


class MotorBit:
    M1 = 0
    M2 = 1
    M3 = 2
    M4 = 3

    A01 = PCA9685.LED0
    A02 = PCA9685.LED1
    A03 = PCA9685.LED2
    A04 = PCA9685.LED3
    B01 = PCA9685.LED4
    B02 = PCA9685.LED5
    B03 = PCA9685.LED6
    B04 = PCA9685.LED7

    S1 = PCA9685.LED8
    S2 = PCA9685.LED9
    S3 = PCA9685.LED10
    S4 = PCA9685.LED11
    S5 = PCA9685.LED12
    S6 = PCA9685.LED13
    S7 = PCA9685.LED14
    S8 = PCA9685.LED15

    class DcMotor:

        def __init__(self, pca9685, positive_channel, negative_channel) -> None:
            self._pca9685 = pca9685
            self._positive_channel = positive_channel
            self._negative_channel = negative_channel

        @property
        def speed(self):
            raise NotImplementedError()

        @speed.setter
        def speed(self, speed):
            if speed < -4095 or speed > 4095:
                raise ValueError(
                    "{} is out of range for speed (-4095 - 4095)".format(speed))

            if speed >= 0:
                self._pca9685.duty(self._positive_channel, round(abs(speed)))
                self._pca9685.duty(self._negative_channel, 0)
            else:
                self._pca9685.duty(self._negative_channel, round(abs(speed)))
                self._pca9685.duty(self._positive_channel, 0)

    class Servo:

        def __init__(
            self,
            pca9685,
            channel,
        ) -> None:
            self._pca9685 = pca9685
            self._channel = channel
            self._max_rotation_angle = 180
            self._min_pulse_width_us = 500
            self._max_pulse_width_us = 2500

        @property
        def angle(self):
            raise NotImplementedError()

        @angle.setter
        def angle(self, angle):
            if angle < 0 or angle > self._max_rotation_angle:
                raise ValueError('{} is out of range for angle (0 ~ {})'.format(
                    angle, self._max_rotation_angle))

            duty = (self._min_pulse_width_us +
                    float(angle) / self._max_rotation_angle *
                    (self._max_pulse_width_us - self._min_pulse_width_us)) / (
                        1000000 / self._pca9685.frequency_hz) * 4095
            self._pca9685.duty(self._channel, round(duty))

        @property
        def max_rotation_angle(self):
            return self._max_rotation_angle

        @max_rotation_angle.setter
        def max_rotation_angle(self, max_rotation_angle):
            self._max_rotation_angle = max_rotation_angle

        @property
        def min_pulse_width_us(self):
            return self._min_pulse_width_us

        @min_pulse_width_us.setter
        def min_pulse_width_us(self, min_pulse_width_us):
            self._min_pulse_width_us = min_pulse_width_us

        @property
        def max_pulse_width_us(self):
            return self._max_pulse_width_us

        @max_pulse_width_us.setter
        def max_pulse_width_us(self, max_pulse_width_us):
            self._max_pulse_width_us = max_pulse_width_us

    def __init__(self) -> None:
        self._pca9685 = PCA9685()
        self._dc_motors = (
            MotorBit.DcMotor(self._pca9685, MotorBit.A01, MotorBit.A02),
            MotorBit.DcMotor(self._pca9685, MotorBit.A03, MotorBit.A04),
            MotorBit.DcMotor(self._pca9685, MotorBit.B01, MotorBit.B02),
            MotorBit.DcMotor(self._pca9685, MotorBit.B03, MotorBit.B04),
        )
        self._servos = (
            MotorBit.Servo(self._pca9685, MotorBit.S1),
            MotorBit.Servo(self._pca9685, MotorBit.S2),
            MotorBit.Servo(self._pca9685, MotorBit.S3),
            MotorBit.Servo(self._pca9685, MotorBit.S4),
            MotorBit.Servo(self._pca9685, MotorBit.S5),
            MotorBit.Servo(self._pca9685, MotorBit.S6),
            MotorBit.Servo(self._pca9685, MotorBit.S7),
            MotorBit.Servo(self._pca9685, MotorBit.S8),
        )

    @property
    def pca9685(self) -> PCA9685:
        return self._pca9685

    def dc_motor(self, index):
        if index < MotorBit.M1 or index > MotorBit.M4:
            raise ValueError(
                '{} is out of range for index (MotorBit.M1({}) ~ MotorBit.M4({}))'
                .format(index, MotorBit.M1, MotorBit.M4))

        return self._dc_motors[index - MotorBit.M1]

    def servo(self, index):
        if index < MotorBit.S1 or index > MotorBit.S8:
            raise ValueError(
                '{} is out of range for index (MotorBit.S1({}) ~ MotorBit.S8({}))'
                .format(index, MotorBit.S1, MotorBit.S8))

        return self._servos[index - MotorBit.S1]
