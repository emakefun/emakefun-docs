from pca9685 import PCA9685
from micropython import const


class MotorBitV2:
    VERSION = const(2)

    M1 = const(0)
    M2 = const(1)
    M3 = const(2)
    M4 = const(3)

    A01 = const(PCA9685.LED0)
    A02 = const(PCA9685.LED1)
    A03 = const(PCA9685.LED2)
    A04 = const(PCA9685.LED3)
    B01 = const(PCA9685.LED4)
    B02 = const(PCA9685.LED5)
    B03 = const(PCA9685.LED6)
    B04 = const(PCA9685.LED7)

    S1 = const(PCA9685.LED8)
    S2 = const(PCA9685.LED9)
    S3 = const(PCA9685.LED10)
    S4 = const(PCA9685.LED11)
    S5 = const(PCA9685.LED12)
    S6 = const(PCA9685.LED13)
    S7 = const(PCA9685.LED14)
    S8 = const(PCA9685.LED15)


class MotorBitV2:
    M1 = 0
    M2 = 1
    M3 = 2
    M4 = 3

    A01 = PCA9685.LED0
    A02 = PCA9685.LED1
    A03 = PCA9685.LED2
    A04 = PCA9685.LED3
    B01 = PCA9685.LED4
    B02 = PCA9685.LED5
    B03 = PCA9685.LED6
    B04 = PCA9685.LED7

    S1 = PCA9685.LED8
    S2 = PCA9685.LED9
    S3 = PCA9685.LED10
    S4 = PCA9685.LED11
    S5 = PCA9685.LED12
    S6 = PCA9685.LED13
    S7 = PCA9685.LED14
    S8 = PCA9685.LED15

    class DcMotor:

        def __init__(self, pca9685, positive_channel, negative_channel) -> None:
            self._pca9685 = pca9685
            self._positive_channel = positive_channel
            self._negative_channel = negative_channel

        @property
        def speed(self):
            raise NotImplementedError()

        @speed.setter
        def speed(self, speed):
            if speed < -4095 or speed > 4095:
                raise ValueError(
                    "{} is out of range for speed (-4095 - 4095)".format(speed))

            if speed >= 0:
                self._pca9685.duty(self._positive_channel, round(abs(speed)))
                self._pca9685.duty(self._negative_channel, 0)
            else:
                self._pca9685.duty(self._negative_channel, round(abs(speed)))
                self._pca9685.duty(self._positive_channel, 0)

    class Servo:

        def __init__(
            self,
            pca9685,
            channel,
        ) -> None:
            self._pca9685 = pca9685
            self._channel = channel
            self._max_rotation_angle = 180
            self._min_pulse_width_us = 500
            self._max_pulse_width_us = 2500

        @property
        def angle(self):
            raise NotImplementedError()

        @angle.setter
        def angle(self, angle):
            if angle < 0 or angle > self._max_rotation_angle:
                raise ValueError('{} is out of range for angle (0 ~ {})'.format(
                    angle, self._max_rotation_angle))

            duty = (self._min_pulse_width_us +
                    float(angle) / self._max_rotation_angle *
                    (self._max_pulse_width_us - self._min_pulse_width_us)) / (
                        1000000 / self._pca9685.frequency_hz) * 4095
            self._pca9685.duty(self._channel, round(duty))

        @property
        def max_rotation_angle(self):
            return self._max_rotation_angle

        @max_rotation_angle.setter
        def max_rotation_angle(self, max_rotation_angle):
            self._max_rotation_angle = max_rotation_angle

        @property
        def min_pulse_width_us(self):
            return self._min_pulse_width_us

        @min_pulse_width_us.setter
        def min_pulse_width_us(self, min_pulse_width_us):
            self._min_pulse_width_us = min_pulse_width_us

        @property
        def max_pulse_width_us(self):
            return self._max_pulse_width_us

        @max_pulse_width_us.setter
        def max_pulse_width_us(self, max_pulse_width_us):
            self._max_pulse_width_us = max_pulse_width_us

    def __init__(self, i2c) -> None:
        self._pca9685 = PCA9685(i2c)
        self._dc_motors = (
            MotorBitV2.DcMotor(self._pca9685, MotorBitV2.A01, MotorBitV2.A02),
            MotorBitV2.DcMotor(self._pca9685, MotorBitV2.A03, MotorBitV2.A04),
            MotorBitV2.DcMotor(self._pca9685, MotorBitV2.B01, MotorBitV2.B02),
            MotorBitV2.DcMotor(self._pca9685, MotorBitV2.B03, MotorBitV2.B04),
        )
        self._servos = (
            MotorBitV2.Servo(self._pca9685, MotorBitV2.S1),
            MotorBitV2.Servo(self._pca9685, MotorBitV2.S2),
            MotorBitV2.Servo(self._pca9685, MotorBitV2.S3),
            MotorBitV2.Servo(self._pca9685, MotorBitV2.S4),
            MotorBitV2.Servo(self._pca9685, MotorBitV2.S5),
            MotorBitV2.Servo(self._pca9685, MotorBitV2.S6),
            MotorBitV2.Servo(self._pca9685, MotorBitV2.S7),
            MotorBitV2.Servo(self._pca9685, MotorBitV2.S8),
        )

    @property
    def pca9685(self) -> PCA9685:
        return self._pca9685

    def dc_motor(self, index):
        if index < MotorBitV2.M1 or index > MotorBitV2.M4:
            raise ValueError(
                '{} is out of range for index (MotorBitV2.M1({}) ~ MotorBitV2.M4({}))'
                .format(index, MotorBitV2.M1, MotorBitV2.M4))

        return self._dc_motors[index - MotorBitV2.M1]

    def servo(self, index):
        if index < MotorBitV2.S1 or index > MotorBitV2.S8:
            raise ValueError(
                '{} is out of range for index (MotorBitV2.S1({}) ~ MotorBitV2.S8({}))'
                .format(index, MotorBitV2.S1, MotorBitV2.S8))

        return self._servos[index - MotorBitV2.S1]
