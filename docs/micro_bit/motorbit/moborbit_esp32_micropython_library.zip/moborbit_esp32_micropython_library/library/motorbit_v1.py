from pca9685 import PCA9685
from micropython import const
import time


class MotorBitV1:
    VERSION = const(1)

    M1 = const(0)
    M2 = const(1)
    M3 = const(2)
    M4 = const(3)

    A01 = PCA9685.LED0
    A02 = PCA9685.LED1
    A03 = PCA9685.LED2
    A04 = PCA9685.LED3
    B01 = PCA9685.LED4
    B02 = PCA9685.LED5
    B03 = PCA9685.LED6
    B04 = PCA9685.LED7

    S1 = PCA9685.LED8
    S2 = PCA9685.LED9
    S3 = PCA9685.LED10
    S4 = PCA9685.LED11
    S5 = PCA9685.LED12
    S6 = PCA9685.LED13
    S7 = PCA9685.LED14
    S8 = PCA9685.LED15

    SM1 = const(0)
    SM2 = const(1)

    class DcMotor:

        def __init__(self, pca9685, positive_channel, negative_channel) -> None:
            self._pca9685 = pca9685
            self._positive_channel = positive_channel
            self._negative_channel = negative_channel

        @property
        def speed(self):
            raise NotImplementedError()

        @speed.setter
        def speed(self, speed):
            if speed < -4095 or speed > 4095:
                raise ValueError(
                    "{} is out of range for speed (-4095 - 4095)".format(speed))

            if speed >= 0:
                self._pca9685.duty(self._positive_channel, round(abs(speed)))
                self._pca9685.duty(self._negative_channel, 0)
            else:
                self._pca9685.duty(self._negative_channel, round(abs(speed)))
                self._pca9685.duty(self._positive_channel, 0)

    class Servo:

        def __init__(
            self,
            pca9685,
            channel,
        ) -> None:
            self._pca9685 = pca9685
            self._channel = channel
            self._max_rotation_angle = 180
            self._min_pulse_width_us = 500
            self._max_pulse_width_us = 2500

        @property
        def angle(self):
            raise NotImplementedError()

        @angle.setter
        def angle(self, angle):
            if angle < 0 or angle > self._max_rotation_angle:
                raise ValueError('{} is out of range for angle (0 ~ {})'.format(
                    angle, self._max_rotation_angle))

            duty = (self._min_pulse_width_us +
                    float(angle) / self._max_rotation_angle *
                    (self._max_pulse_width_us - self._min_pulse_width_us)) / (
                        1000000 / self._pca9685.frequency_hz) * 4095
            self._pca9685.duty(self._channel, round(duty))

        @property
        def max_rotation_angle(self):
            return self._max_rotation_angle

        @max_rotation_angle.setter
        def max_rotation_angle(self, max_rotation_angle):
            self._max_rotation_angle = max_rotation_angle

        @property
        def min_pulse_width_us(self):
            return self._min_pulse_width_us

        @min_pulse_width_us.setter
        def min_pulse_width_us(self, min_pulse_width_us):
            self._min_pulse_width_us = min_pulse_width_us

        @property
        def max_pulse_width_us(self):
            return self._max_pulse_width_us

        @max_pulse_width_us.setter
        def max_pulse_width_us(self, max_pulse_width_us):
            self._max_pulse_width_us = max_pulse_width_us

    class StepperMotor:

        MODE_NONE = const(0)
        MODE_RUN_FORWARD = const(1)
        MODE_RUN_BACKWARD = const(2)
        MODE_RUN_WITH_POSITION = const(3)

        SINGLE_PHASE_FULL_STEP_EXCITATION = const(0)
        TWO_PHASE_FULL_STEP_EXCITATION = const(1)
        HALF_PHASE_EXCITATION = const(2)

        STEPS = (
            (  #A, B, C, D
                (4095, 0, 0, 0),
                (0, 4095, 0, 0),
                (0, 0, 4095, 0),
                (0, 0, 0, 4095),
            ),
            (
                (4095, 4095, 0, 0),
                (0, 4095, 4095, 0),
                (0, 0, 4095, 4095),
                (4095, 0, 0, 4095),
            ),
            (
                (4095, 0, 0, 0),
                (4095, 4095, 0, 0),
                (0, 4095, 0, 0),
                (0, 4095, 4095, 0),
                (0, 0, 4095, 0),
                (0, 0, 4095, 4095),
                (0, 0, 0, 4095),
                (4095, 0, 0, 4095),
            ),
        )

        def __init__(self, pca9685, begin_channel) -> None:
            self._pca9685 = pca9685
            self._begin_channel = begin_channel
            self._excitation = MotorBitV1.StepperMotor.HALF_PHASE_EXCITATION
            self._current_step = 0
            self._target_step = 0
            self._mode = MotorBitV1.StepperMotor.MODE_NONE
            self._last_step_time_us = -1
            self._rpm = 10
            self._step_us = 2000
            self._step_values = MotorBitV1.StepperMotor.STEPS[self._excitation]
            self._update_step_us()

        @property
        def excitation(self):
            return self._excitation

        @excitation.setter
        def excitation(self, excitation):
            self._excitation = excitation
            self._step_values = MotorBitV1.StepperMotor.STEPS[self._excitation]
            self._update_step_us()

        @property
        def rpm(self):
            return self._rpm

        @rpm.setter
        def rpm(self, rpm):
            if self._rpm <= 0:
                raise ValueError(f'{rpm} is not positive value')

            self._rpm = float(rpm)
            self._update_step_us()

        def _update_step_us(self):
            self._step_us = (60 * 1000 * 1000) / (self._rpm * 512 *
                                                  len(self._step_values))

        def _position_to_step(self, position):
            return round(position * 512.0 * len(self._step_values) / 360)

        def _step_to_position(self, step):
            return step * 360.0 / len(self._step_values) / 512

        @property
        def reached_target_position(self):
            return self._mode == MotorBitV1.StepperMotor.MODE_NONE

        @property
        def current_position(self):
            return self._step_to_position(self._current_step)

        @current_position.setter
        def current_position(self, current_position):
            self._current_step = self._position_to_step(current_position)

        @property
        def target_position(self):
            return self._target_position

        def move(self, position):
            self.target_position = self.current_position + position

        @target_position.setter
        def target_position(self, target_position):
            self._target_position = float(target_position)
            self._mode = MotorBitV1.StepperMotor.MODE_RUN_WITH_POSITION
            self._target_step = self._position_to_step(self._target_position)

        def run_forward(self):
            self._mode = MotorBitV1.StepperMotor.MODE_RUN_FORWARD

        def run_backward(self):
            self._mode = MotorBitV1.StepperMotor.MODE_RUN_BACKWARD

        def stop(self):
            self._mode = MotorBitV1.StepperMotor.MODE_NONE
            self._pca9685.duties(self._begin_channel, (4095, 4095, 4095, 4095))

        def step_forward(self):
            self._current_step += 1
            self._update_step()

        def step_backward(self):
            self._current_step -= 1
            self._update_step()

        def tick(self):
            if self._last_step_time_us != -1 and time.ticks_us(
            ) - self._last_step_time_us < self._step_us:
                return

            self._last_step_time_us = time.ticks_us()

            if self._mode == MotorBitV1.StepperMotor.MODE_RUN_WITH_POSITION:
                if self._target_step > self._current_step:
                    self._current_step += 1
                elif self._target_step < self._current_step:
                    self._current_step -= 1
                if self._current_step == self._target_step:
                    self._mode = MotorBitV1.StepperMotor.MODE_NONE
            elif self._mode == MotorBitV1.StepperMotor.MODE_RUN_FORWARD:
                self._current_step += 1
            elif self._mode == MotorBitV1.StepperMotor.MODE_RUN_BACKWARD:
                self._current_step -= 1

            self._update_step()

        def _update_step(self):
            current_step = self._current_step % len(self._step_values)
            if current_step < 0:
                current_step += len(self._step_values)

            step_value = self._step_values[current_step]
            self._pca9685.duties(self._begin_channel, step_value)

    def __init__(self, i2c) -> None:
        self._pca9685 = PCA9685(i2c)
        self._dc_motors = (
            MotorBitV1.DcMotor(self._pca9685, MotorBitV1.A01, MotorBitV1.A02),
            MotorBitV1.DcMotor(self._pca9685, MotorBitV1.A03, MotorBitV1.A04),
            MotorBitV1.DcMotor(self._pca9685, MotorBitV1.B01, MotorBitV1.B02),
            MotorBitV1.DcMotor(self._pca9685, MotorBitV1.B03, MotorBitV1.B04),
        )
        self._servos = (
            MotorBitV1.Servo(self._pca9685, MotorBitV1.S1),
            MotorBitV1.Servo(self._pca9685, MotorBitV1.S2),
            MotorBitV1.Servo(self._pca9685, MotorBitV1.S3),
            MotorBitV1.Servo(self._pca9685, MotorBitV1.S4),
            MotorBitV1.Servo(self._pca9685, MotorBitV1.S5),
            MotorBitV1.Servo(self._pca9685, MotorBitV1.S6),
            MotorBitV1.Servo(self._pca9685, MotorBitV1.S7),
            MotorBitV1.Servo(self._pca9685, MotorBitV1.S8),
        )
        self._stepper_motors = (
            MotorBitV1.StepperMotor(self._pca9685, MotorBitV1.A01),
            MotorBitV1.StepperMotor(self._pca9685, MotorBitV1.B01),
        )

    @property
    def pca9685(self) -> PCA9685:
        return self._pca9685

    def dc_motor(self, index):
        if index < MotorBitV1.M1 or index > MotorBitV1.M4:
            raise ValueError(
                '{} is out of range for index (MotorBitV1.M1({}) ~ MotorBitV1.M4({}))'
                .format(index, MotorBitV1.M1, MotorBitV1.M4))

        return self._dc_motors[index - MotorBitV1.M1]

    def servo(self, index):
        if index < MotorBitV1.S1 or index > MotorBitV1.S8:
            raise ValueError(
                '{} is out of range for index (MotorBitV1.S1({}) ~ MotorBitV1.S8({}))'
                .format(index, MotorBitV1.S1, MotorBitV1.S8))

        return self._servos[index - MotorBitV1.S1]

    def stepper_motor(self, index):
        if index < MotorBitV1.SM1 or index > MotorBitV1.SM2:
            raise ValueError(
                '{} is out of range for index (MotorBitV1.SM1({}) ~ MotorBitV1.SM2({}))'
                .format(index, MotorBitV1.SM1, MotorBitV1.SM2))
        return self._stepper_motors[index - MotorBitV1.SM1]
