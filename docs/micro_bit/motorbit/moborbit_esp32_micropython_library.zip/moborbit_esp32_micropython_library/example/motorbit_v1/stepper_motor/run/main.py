import machine
import time
from motorbit_v1 import MotorBitV1

motorbit = MotorBitV1(machine.I2C(0, scl=22, sda=23))
motorbit.pca9685.frequency_hz = 10000
stepper_motor_1 = motorbit.stepper_motor(MotorBitV1.SM1)
stepper_motor_2 = motorbit.stepper_motor(MotorBitV1.SM2)

stepper_motor_1.excitation = MotorBitV1.StepperMotor.TWO_PHASE_FULL_STEP_EXCITATION  #设置相位激励模式
stepper_motor_1.rpm = 10  #设置速度，速度不宜过快，否则会丢步无法转动，单位RPM
stepper_motor_2.excitation = MotorBitV1.StepperMotor.TWO_PHASE_FULL_STEP_EXCITATION  #设置相位激励模式
stepper_motor_2.rpm = 10  #设置速度，速度不宜过快，否则会丢步无法转动，单位RPM

start_time = time.ticks_ms()
print_time = time.ticks_ms()
forward = True

print('run forward')

while True:
    stepper_motor_1.tick()
    stepper_motor_2.tick()
    if forward is None:
        stepper_motor_1.stop()
        stepper_motor_2.stop()
    elif forward:
        stepper_motor_1.run_forward()
        stepper_motor_2.run_forward()
    else:
        stepper_motor_1.run_backward()
        stepper_motor_2.run_backward()

    if time.ticks_ms() - start_time > 2000:  #超过1s转向或者停止
        start_time = time.ticks_ms()

        if forward is None:
            forward = True
            print('run forward')
        elif forward:
            forward = False
            print('run backward')
        else:
            forward = None
            print('stop')

    if time.ticks_ms() - print_time > 200:  #每隔一段时间打印当前位置
        print_time = time.ticks_ms()
        print(stepper_motor_1.current_position)
