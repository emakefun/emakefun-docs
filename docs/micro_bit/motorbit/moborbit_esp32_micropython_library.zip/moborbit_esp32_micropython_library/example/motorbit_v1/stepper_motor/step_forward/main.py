import machine
import time
from motorbit_v1 import MotorBitV1

motorbit = MotorBitV1(machine.I2C(0, scl=22, sda=23))
motorbit.pca9685.frequency_hz = 10000

stepper_motor_1 = motorbit.stepper_motor(MotorBitV1.SM1)
stepper_motor_2 = motorbit.stepper_motor(MotorBitV1.SM2)

stepper_motor_1.excitation = MotorBitV1.StepperMotor.TWO_PHASE_FULL_STEP_EXCITATION  #设置相位激励模式
stepper_motor_2.excitation = MotorBitV1.StepperMotor.TWO_PHASE_FULL_STEP_EXCITATION  #设置相位激励模式

print("step forward")

while True:
    stepper_motor_1.step_forward()
    stepper_motor_2.step_forward()
    time.sleep_ms(2)
