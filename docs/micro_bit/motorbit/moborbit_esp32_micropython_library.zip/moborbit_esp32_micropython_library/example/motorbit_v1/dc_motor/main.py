from motorbit_v1 import MotorBitV1
import machine
import time

motorbit = MotorBitV1(machine.I2C(0, scl=22, sda=23))

motorbit.pca9685.frequency_hz = 50
print('frequency:', motorbit.pca9685.frequency_hz, ' hz')

while True:
    speed = 4095  # speed range is -4095 ~ 4095
    motorbit.dc_motor(MotorBitV1.M1).speed = speed
    motorbit.dc_motor(MotorBitV1.M2).speed = speed
    motorbit.dc_motor(MotorBitV1.M3).speed = speed
    motorbit.dc_motor(MotorBitV1.M4).speed = speed
    print('dc motor speed:', speed)
    time.sleep(1)

    speed = -4095  # speed range is -4095 ~ 4095
    motorbit.dc_motor(MotorBitV1.M1).speed = speed
    motorbit.dc_motor(MotorBitV1.M2).speed = speed
    motorbit.dc_motor(MotorBitV1.M3).speed = speed
    motorbit.dc_motor(MotorBitV1.M4).speed = speed
    print('dc motor speed:', speed)
    time.sleep(1)

    speed = 0  # speed range is -4095 ~ 4095
    motorbit.dc_motor(MotorBitV1.M1).speed = speed
    motorbit.dc_motor(MotorBitV1.M2).speed = speed
    motorbit.dc_motor(MotorBitV1.M3).speed = speed
    motorbit.dc_motor(MotorBitV1.M4).speed = speed
    print('dc motor speed:', speed)
    time.sleep(1)
