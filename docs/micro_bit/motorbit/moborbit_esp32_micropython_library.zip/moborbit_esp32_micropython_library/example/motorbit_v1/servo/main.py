from motorbit_v1 import MotorBitV1
import machine
import time

motorbit = MotorBitV1(machine.I2C(0, scl=22, sda=23))

motorbit.pca9685.frequency_hz = 50

while True:
    angle = 0
    motorbit.servo(MotorBitV1.S1).angle = angle
    motorbit.servo(MotorBitV1.S2).angle = angle
    motorbit.servo(MotorBitV1.S3).angle = angle
    motorbit.servo(MotorBitV1.S4).angle = angle
    motorbit.servo(MotorBitV1.S5).angle = angle
    motorbit.servo(MotorBitV1.S6).angle = angle
    motorbit.servo(MotorBitV1.S7).angle = angle
    motorbit.servo(MotorBitV1.S8).angle = angle
    print('angle:', angle)
    time.sleep(1)

    angle = 90
    motorbit.servo(MotorBitV1.S1).angle = angle
    motorbit.servo(MotorBitV1.S2).angle = angle
    motorbit.servo(MotorBitV1.S3).angle = angle
    motorbit.servo(MotorBitV1.S4).angle = angle
    motorbit.servo(MotorBitV1.S5).angle = angle
    motorbit.servo(MotorBitV1.S6).angle = angle
    motorbit.servo(MotorBitV1.S7).angle = angle
    motorbit.servo(MotorBitV1.S8).angle = angle
    print('angle:', angle)
    time.sleep(1)

    angle = 180
    motorbit.servo(MotorBitV1.S1).angle = angle
    motorbit.servo(MotorBitV1.S2).angle = angle
    motorbit.servo(MotorBitV1.S3).angle = angle
    motorbit.servo(MotorBitV1.S4).angle = angle
    motorbit.servo(MotorBitV1.S5).angle = angle
    motorbit.servo(MotorBitV1.S6).angle = angle
    motorbit.servo(MotorBitV1.S7).angle = angle
    motorbit.servo(MotorBitV1.S8).angle = angle
    print('angle:', angle)
    time.sleep(1)
