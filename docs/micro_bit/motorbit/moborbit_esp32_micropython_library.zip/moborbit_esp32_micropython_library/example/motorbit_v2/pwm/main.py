from motorbit_v2 import MotorBitV2
import machine
from pca9685 import PCA9685
import time

motorbit = MotorBitV2(machine.I2C(0, scl=22, sda=23))

motorbit.pca9685.frequency_hz = 50

# MotorBitV2's A01 is equivalent to PCA9685's LED0
# MotorBitV2's A02 is equivalent to PCA9685's LED1
# MotorBitV2's A03 is equivalent to PCA9685's LED2
# MotorBitV2's A04 is equivalent to PCA9685's LED3

# MotorBitV2's B01 is equivalent to PCA9685's LED4
# MotorBitV2's B02 is equivalent to PCA9685's LED5
# MotorBitV2's B03 is equivalent to PCA9685's LED6
# MotorBitV2's B04 is equivalent to PCA9685's LED7

# MotorBitV2's S1 is equivalent to PCA9685's LED8
# MotorBitV2's S2 is equivalent to PCA9685's LED9
# MotorBitV2's S3 is equivalent to PCA9685's LED10
# MotorBitV2's S4 is equivalent to PCA9685's LED11
# MotorBitV2's S5 is equivalent to PCA9685's LED12
# MotorBitV2's S6 is equivalent to PCA9685's LED13
# MotorBitV2's S7 is equivalent to PCA9685's LED14
# MotorBitV2's S8 is equivalent to PCA9685's LED15
# example: motorbit.pca9685.duty(MotorBitV2.S1, 4095) is equivalent to motorbit.pca9685.duty(PCA9685.LED8, 4095)

# duty range is 0 ~ 4095 (0% ~ 100%)

motorbit.pca9685.duty(MotorBitV2.S1, 4095)  # 100%
motorbit.pca9685.duty(MotorBitV2.S2, 2048)  # 50%
motorbit.pca9685.duty(MotorBitV2.S3, 1024)  # 25%
motorbit.pca9685.duty(MotorBitV2.S4, 0)  # 0%
motorbit.pca9685.duty(MotorBitV2.S5, 4095)  # 100%
motorbit.pca9685.duty(MotorBitV2.S6, 2048)  # 50%
motorbit.pca9685.duty(MotorBitV2.S7, 1024)  # 25%
motorbit.pca9685.duty(MotorBitV2.S8, 0)  # 0%

motorbit.pca9685.duty(MotorBitV2.A01, 4095)  # 100%
motorbit.pca9685.duty(MotorBitV2.A02, 2048)  # 50%
motorbit.pca9685.duty(MotorBitV2.A03, 1024)  # 25%
motorbit.pca9685.duty(MotorBitV2.A04, 0)  # 0%

motorbit.pca9685.duty(MotorBitV2.B01, 4095)  # 100%
motorbit.pca9685.duty(MotorBitV2.B02, 2048)  # 50%
motorbit.pca9685.duty(MotorBitV2.B03, 1024)  # 25%
motorbit.pca9685.duty(MotorBitV2.B04, 0)  # 0%
