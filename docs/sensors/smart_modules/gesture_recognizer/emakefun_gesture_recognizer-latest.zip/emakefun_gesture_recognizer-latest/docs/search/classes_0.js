var searchData=
[
  ['gesturerecognizer_0',['GestureRecognizer',['../classemakefun_1_1_gesture_recognizer.html',1,'emakefun']]]
];
