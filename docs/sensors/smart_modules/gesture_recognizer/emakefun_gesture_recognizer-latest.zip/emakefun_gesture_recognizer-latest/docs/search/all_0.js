var searchData=
[
  ['gesture_0',['Gesture',['../classemakefun_1_1_gesture_recognizer.html#a926f8fa252fe3ec44f48d0d95dbb77fa',1,'emakefun::GestureRecognizer']]],
  ['gesturerecognizer_1',['GestureRecognizer',['../classemakefun_1_1_gesture_recognizer.html',1,'emakefun::GestureRecognizer'],['../classemakefun_1_1_gesture_recognizer.html#abcc5b2a7672bf550a41ef607f0966613',1,'emakefun::GestureRecognizer::GestureRecognizer(const uint8_t i2c_address=kDefaultI2cAddress)']]],
  ['getgesture_2',['GetGesture',['../classemakefun_1_1_gesture_recognizer.html#a0bdbe3563bd61160956089a86f41caed',1,'emakefun::GestureRecognizer']]]
];
