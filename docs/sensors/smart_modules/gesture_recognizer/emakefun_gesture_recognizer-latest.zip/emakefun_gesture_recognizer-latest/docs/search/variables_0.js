var searchData=
[
  ['kdefaulti2caddress_0',['kDefaultI2cAddress',['../classemakefun_1_1_gesture_recognizer.html#a6a869d23742ec2ce2d32f461a737f1c3',1,'emakefun::GestureRecognizer']]]
];
