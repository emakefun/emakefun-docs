var searchData=
[
  ['gesturerecognizer_0',['GestureRecognizer',['../classemakefun_1_1_gesture_recognizer.html#abcc5b2a7672bf550a41ef607f0966613',1,'emakefun::GestureRecognizer']]],
  ['getgesture_1',['GetGesture',['../classemakefun_1_1_gesture_recognizer.html#a0bdbe3563bd61160956089a86f41caed',1,'emakefun::GestureRecognizer']]]
];
