var searchData=
[
  ['gesture_0',['Gesture',['../classemakefun_1_1_gesture_recognizer.html#a926f8fa252fe3ec44f48d0d95dbb77fa',1,'emakefun::GestureRecognizer']]]
];
