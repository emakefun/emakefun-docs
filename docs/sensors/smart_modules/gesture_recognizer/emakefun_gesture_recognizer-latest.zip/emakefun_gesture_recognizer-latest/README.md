# 手势识别模块

该库是易创空间的手势识别模块的Arduino库，支持的开发板如下列表所示：

| 支持的开发板系列 |
| --- |
| Arduino 系列 |
| ESP32 系列 |
| ESP32S3 系列 |

## 产品详情

- 产品详情：[产品详情链接](https://emakefun-docs.readthedocs.io/zh_CN/latest/sensors/smart_modules/gesture_recognizer/)

## 主类和接口说明

- 主类和接口说明：[点击此处链接查看](https://emakefun-arduino-library.github.io/emakefun_gesture_recognizer/classemakefun_1_1_gesture_recognizer.html)

## 示例程序

- 识别手势并打印：[点击此处链接查看](https://emakefun-arduino-library.github.io/emakefun_gesture_recognizer/get_gesture_8ino-example.html)
