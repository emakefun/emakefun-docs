#include "i2c_expansion_board.h"

#include <Wire.h>
#include <arduino.h>

/**
static_assert(offsetof(UserData, version) == 0x00);
static_assert(offsetof(UserData, io_mode) == 0x01);
static_assert(offsetof(UserData, digital_values) == 0x09);
static_assert(offsetof(UserData, analog_values) == 0x12);
static_assert(offsetof(UserData, pwm_frequency) == 0x24);
static_assert(offsetof(UserData, pwm_duty) == 0x28);
*/
#define ADDRESS_VERSION (0x00)
#define ADDRESS_IO_MODE (0x01)
#define ADDRESS_DIGITAL_VALUES (0x09)
#define ADDRESS_ANALOG_VALUES (0x12)
#define ADDRESS_PWM_FREQUENCY (0x24)
#define ADDRESS_PWM_DUTY (0x28)

I2cExpansionBoard::I2cExpansionBoard(uint8_t device_i2c_address) : device_i2c_address_(device_i2c_address) {
  Wire.begin();
}

bool I2cExpansionBoard::SetGpioMode(I2cExpansionBoard::GpioPin gpio_pin, I2cExpansionBoard::GpioMode mode) {
  Wire.beginTransmission(device_i2c_address_);
  Wire.write(ADDRESS_IO_MODE + gpio_pin);
  Wire.write(mode);
  auto ret = Wire.endTransmission();
  if (ret != 0) {
    Serial.print("Error occurred when i2c writing: ");
    Serial.println(ret);
    return false;
  }

  return true;
}

bool I2cExpansionBoard::SetGpioLevel(I2cExpansionBoard::GpioPin gpio_pin, uint8_t level) {
  Wire.beginTransmission(device_i2c_address_);
  Wire.write(ADDRESS_DIGITAL_VALUES + gpio_pin);
  Wire.write(level);
  if (0 != Wire.endTransmission()) {
    return false;
  }
  return true;
}

uint8_t I2cExpansionBoard::GetGpioLevel(I2cExpansionBoard::GpioPin gpio_pin) {
  Wire.beginTransmission(device_i2c_address_);
  Wire.write(ADDRESS_DIGITAL_VALUES + gpio_pin);
  if (0 != Wire.endTransmission()) {
    return 0;
  }

  Wire.requestFrom(device_i2c_address_, (uint8_t)1);
  if (Wire.available()) {
    return Wire.read();
  }

  return 0;
}

uint16_t I2cExpansionBoard::GetGpioAdcValue(I2cExpansionBoard::GpioPin gpio_pin) {
  Wire.beginTransmission(device_i2c_address_);
  Wire.write(ADDRESS_ANALOG_VALUES + gpio_pin * sizeof(uint16_t));
  if (0 != Wire.endTransmission()) {
    return 0;
  }

  uint16_t analog_value = 0;
  Wire.requestFrom(device_i2c_address_, (uint8_t)2);
  for (int i = 0; i < sizeof(analog_value) && Wire.available(); i++) {
    reinterpret_cast<uint8_t*>(&analog_value)[i] = Wire.read();
  }

  return analog_value;
}

bool I2cExpansionBoard::SetPwmFrequency(uint32_t frequency) {
  Wire.beginTransmission(device_i2c_address_);
  Wire.write(ADDRESS_PWM_FREQUENCY);
  Wire.write(reinterpret_cast<uint8_t*>(&frequency), sizeof(frequency));
  return Wire.endTransmission() == 0;
}

bool I2cExpansionBoard::SetPwmDuty(GpioPin gpio_pin, uint8_t duty) {
  Wire.beginTransmission(device_i2c_address_);
  Wire.write(ADDRESS_PWM_DUTY + gpio_pin);
  Wire.write(duty);
  return Wire.endTransmission() == 0;
}

bool I2cExpansionBoard::SetServoAngle(GpioPin gpio_pin, float angle) {
  return SetPwmFrequency(50) && SetPwmDuty(gpio_pin, static_cast<uint8_t>(((angle / 90) + 0.5) * 100 / 20)) &&
         SetGpioMode(gpio_pin, kPwm);
}
