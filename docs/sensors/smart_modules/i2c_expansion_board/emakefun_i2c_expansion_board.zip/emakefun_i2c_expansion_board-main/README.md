#### ADC输入

```c++
#include <Arduino.h>

#include "i2c_expansion_board.h"

// 创建 I2cExpansionBoard 实例
I2cExpansionBoard i2c_expansion_board;

void setup() {
  // 初始化串口通信
  Serial.begin(115200);
  Serial.println("setup");

  // 配置E0为ADC模式
  i2c_expansion_board.SetGpioMode(I2cExpansionBoard::kGpioPinE0, I2cExpansionBoard::kAdc);
}

void loop() {
  Serial.print("adc value:");
  // 读取E0的ADC值并打印
  Serial.println(i2c_expansion_board.GetGpioAdcValue(I2cExpansionBoard::kGpioPinE0));
  delay(100);
}

```

#### 数字高低电平输入

```c++

#include <Arduino.h>

#include "i2c_expansion_board.h"

// 创建 I2cExpansionBoard 实例
I2cExpansionBoard i2c_expansion_board;

void setup() {
  // 初始化串口通信
  Serial.begin(115200);
  Serial.println("setup");

  // 配置E0为输入模式，默认拉高电平
  i2c_expansion_board.SetGpioMode(I2cExpansionBoard::kGpioPinE0, I2cExpansionBoard::kInputPullDown);
}

void loop() {
  Serial.print("digital value:");
  // 读取E0的数字值并打印
  Serial.println(i2c_expansion_board.GetGpioLevel(I2cExpansionBoard::kGpioPinE0));
  delay(100);
}

```

#### 数字高低电平输出

```c++

#include <Arduino.h>

#include "i2c_expansion_board.h"

// 创建 I2cExpansionBoard 实例
I2cExpansionBoard i2c_expansion_board;

void setup() {
  // 初始化串口通信
  Serial.begin(115200);
  Serial.println("setup");

  // 配置E0为输出模式
  i2c_expansion_board.SetGpioMode(I2cExpansionBoard::kGpioPinE0, I2cExpansionBoard::kOutput);
}

void loop() {
  // 设置E0的输出高电平
  i2c_expansion_board.SetGpioLevel(I2cExpansionBoard::kGpioPinE0, 1);
  delay(100);
  // 设置E0的输出低电平
  i2c_expansion_board.SetGpioLevel(I2cExpansionBoard::kGpioPinE0, 0);
  delay(100);
}

```

#### 舵机控制(只支持E1 ~ E2)

```c++

#include <Arduino.h>

#include "i2c_expansion_board.h"

// 创建 I2cExpansionBoard 实例
I2cExpansionBoard i2c_expansion_board;

void setup() {
  // 初始化串口通信
  Serial.begin(115200);
  Serial.println("setup");
  i2c_expansion_board.SetGpioMode(I2cExpansionBoard::kGpioPinE1, I2cExpansionBoard::kPwm);
  i2c_expansion_board.SetGpioMode(I2cExpansionBoard::kGpioPinE2, I2cExpansionBoard::kPwm);
}

// 注意，舵机控制只支持E1 ~ E2
void loop() {
  // 设置E1舵机转动到0度位置
  i2c_expansion_board.SetServoAngle(I2cExpansionBoard::kGpioPinE1, 0);
  delay(500);

  // 设置E2舵机转动到0度位置
  i2c_expansion_board.SetServoAngle(I2cExpansionBoard::kGpioPinE2, 0);
  delay(500);

  // 设置E1舵机转动到90度位置
  i2c_expansion_board.SetServoAngle(I2cExpansionBoard::kGpioPinE1, 90);
  delay(500);

  // 设置E2舵机转动到90度位置
  i2c_expansion_board.SetServoAngle(I2cExpansionBoard::kGpioPinE2, 90);
  delay(500);

  // 设置E1舵机转动到180度位置
  i2c_expansion_board.SetServoAngle(I2cExpansionBoard::kGpioPinE1, 180);
  delay(500);

  // 设置E2舵机转动到180度位置
  i2c_expansion_board.SetServoAngle(I2cExpansionBoard::kGpioPinE2, 180);
  delay(500);
}

```
