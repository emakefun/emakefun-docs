#ifndef _TTS_H_
#define _TTS_H_
#include <SoftwareSerial.h>

class TTS : public SoftwareSerial
{
public:
		uint8_t buff[0xFF];
		uint8_t buff_size;
public:
		TTS(uint8_t receivePin, uint8_t transmitPin, bool inverse_logic = false):SoftwareSerial(receivePin, transmitPin, inverse_logic){}
		~TTS();
		void SendHeardCmd();
		void StartCmd();
		void TextCacheCmd();
		void SpeechSynthesisCmd();
		void ReturnStatus();
};

#endif
