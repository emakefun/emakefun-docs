#include "TTS.h"

TTS::~TTS()
{
	
}
void TTS::SendHeardCmd()
{
  write((uint8_t)0xFD);
  write((uint8_t)0x00);
}
//发送UTF8格式数据 
void TTS::StartCmd()
{
  SendHeardCmd();
  write(buff_size + 2);
  write(0x01);
  write(0x04);
  for(uint8_t i = 0; i < buff_size; i++){
    write(buff[i]);
  }
}
//文本缓存功能
void TTS::TextCacheCmd()
{
  SendHeardCmd();
  write(buff_size + 2);
  write(0x31);
  write(0x04);
  for(uint8_t i = 0; i < buff_size; i++){
    write(buff[i]);
  }
}
//下位机缓存数据进行TTS合成
void TTS::SpeechSynthesisCmd()
{
  write((uint8_t)0xFD);
  write((uint8_t)0x00);
  write((uint8_t)0x02);
  write((uint8_t)0x32);
  write((uint8_t)0x14);
}

//返回状态
void TTS::ReturnStatus()
{
  while (available()) { // slave may send less than requested
    uint8_t c = read(); // receive a byte as character
    println(c, HEX);         // print the character
//    Serial.println(c, HEX);
  }  
}
