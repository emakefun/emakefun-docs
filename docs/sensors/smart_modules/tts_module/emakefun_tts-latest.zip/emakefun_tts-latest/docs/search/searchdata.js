var indexSectionsWithContent =
{
  0: "eikprst",
  1: "t",
  2: "iprst",
  3: "k",
  4: "et",
  5: "k"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "functions",
  3: "variables",
  4: "enums",
  5: "enumvalues"
};

var indexSectionLabels =
{
  0: "全部",
  1: "类",
  2: "函数",
  3: "变量",
  4: "枚举",
  5: "枚举值"
};

