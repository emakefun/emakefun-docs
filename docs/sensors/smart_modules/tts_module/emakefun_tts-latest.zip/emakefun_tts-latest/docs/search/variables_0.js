var searchData=
[
  ['kdefaulti2caddress_0',['kDefaultI2cAddress',['../classemakefun_1_1_tts.html#aec55cb265f5fe274311815423f33b604',1,'emakefun::Tts']]],
  ['kmaxcacheindex_1',['kMaxCacheIndex',['../classemakefun_1_1_tts.html#a51434dee82b13ac5bef7e519d5b3bb0c',1,'emakefun::Tts']]],
  ['kmaxspeechcount_2',['kMaxSpeechCount',['../classemakefun_1_1_tts.html#aaa966a3e080732e26e5783bfb6dfb303',1,'emakefun::Tts']]],
  ['kmaxtextbytessize_3',['kMaxTextBytesSize',['../classemakefun_1_1_tts.html#a13b1446cb5551be09eec2ce023f8cee7',1,'emakefun::Tts']]],
  ['kminspeechcount_4',['kMinSpeechCount',['../classemakefun_1_1_tts.html#aa4b5286527ccb28439b9f8cff56fd83a',1,'emakefun::Tts']]]
];
