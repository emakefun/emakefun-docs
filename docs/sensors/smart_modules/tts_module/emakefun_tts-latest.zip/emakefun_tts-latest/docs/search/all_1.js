var searchData=
[
  ['initialize_0',['Initialize',['../classemakefun_1_1_tts.html#a857d6835e631eddf88bd409e96a3ad25',1,'emakefun::Tts']]]
];
