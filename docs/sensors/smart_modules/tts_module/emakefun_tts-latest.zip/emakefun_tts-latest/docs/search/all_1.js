var searchData=
[
  ['initialize_0',['Initialize',['../classemakefun_1_1_tts.html#adab3385915c0573bb60ee1a3e58a5402',1,'emakefun::Tts']]]
];
