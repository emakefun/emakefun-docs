var searchData=
[
  ['recognitionmode_0',['RecognitionMode',['../classemakefun_1_1_speech_recognizer.html#a5b0e92735e29f754fb62982721f1c887',1,'emakefun::SpeechRecognizer']]]
];
