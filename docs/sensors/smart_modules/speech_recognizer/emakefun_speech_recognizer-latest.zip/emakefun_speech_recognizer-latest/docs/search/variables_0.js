var searchData=
[
  ['kdefaulti2caddress_0',['kDefaultI2cAddress',['../classemakefun_1_1_speech_recognizer.html#a29f8615dc251f4092b8a523a5c79d9cc',1,'emakefun::SpeechRecognizer']]],
  ['kmaxkeyworddatabytes_1',['kMaxKeywordDataBytes',['../classemakefun_1_1_speech_recognizer.html#a673e593f6126e66ad55168f450cdcaef',1,'emakefun::SpeechRecognizer']]]
];
