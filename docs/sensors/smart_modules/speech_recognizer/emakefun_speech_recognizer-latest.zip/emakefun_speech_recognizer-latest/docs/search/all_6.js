var searchData=
[
  ['setrecognitionmode_0',['SetRecognitionMode',['../classemakefun_1_1_speech_recognizer.html#ade26e52c0ace43fda17f05d7b8440361',1,'emakefun::SpeechRecognizer']]],
  ['settimeout_1',['SetTimeout',['../classemakefun_1_1_speech_recognizer.html#adfa57a3837637c9be378190e1d8734bd',1,'emakefun::SpeechRecognizer']]],
  ['speechrecognizer_2',['SpeechRecognizer',['../classemakefun_1_1_speech_recognizer.html',1,'emakefun::SpeechRecognizer'],['../classemakefun_1_1_speech_recognizer.html#aad858561cb112c7e03566b1e76330f58',1,'emakefun::SpeechRecognizer::SpeechRecognizer()']]]
];
