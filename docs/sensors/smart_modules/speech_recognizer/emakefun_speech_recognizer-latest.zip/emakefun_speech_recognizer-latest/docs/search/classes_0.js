var searchData=
[
  ['speechrecognizer_0',['SpeechRecognizer',['../classemakefun_1_1_speech_recognizer.html',1,'emakefun']]]
];
