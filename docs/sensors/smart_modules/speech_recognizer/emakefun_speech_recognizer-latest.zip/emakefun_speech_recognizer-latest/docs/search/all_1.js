var searchData=
[
  ['event_0',['Event',['../classemakefun_1_1_speech_recognizer.html#af2f981ed4e3e6dafc8a2d8d703455715',1,'emakefun::SpeechRecognizer']]]
];
