var searchData=
[
  ['recognitionmode_0',['RecognitionMode',['../classemakefun_1_1_speech_recognizer.html#a5b0e92735e29f754fb62982721f1c887',1,'emakefun::SpeechRecognizer']]],
  ['recognize_1',['Recognize',['../classemakefun_1_1_speech_recognizer.html#a728e6abcd832e5b779fb1a801c3b3e08',1,'emakefun::SpeechRecognizer']]]
];
