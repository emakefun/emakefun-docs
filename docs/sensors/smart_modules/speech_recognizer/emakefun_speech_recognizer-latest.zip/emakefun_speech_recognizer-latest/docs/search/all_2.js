var searchData=
[
  ['getevent_0',['GetEvent',['../classemakefun_1_1_speech_recognizer.html#a2cb06e53c0992b33a94f17d0afee6957',1,'emakefun::SpeechRecognizer']]]
];
