var searchData=
[
  ['recognize_0',['Recognize',['../classemakefun_1_1_speech_recognizer.html#a728e6abcd832e5b779fb1a801c3b3e08',1,'emakefun::SpeechRecognizer']]]
];
