var searchData=
[
  ['initialize_0',['Initialize',['../classemakefun_1_1_speech_recognizer.html#a4a3a234ad04f4bda6fcfb8e8f5cd5585',1,'emakefun::SpeechRecognizer']]]
];
