#ifndef BS818A_h
#define BS818A_h

#include <Arduino.h>

#define BS_KEYCODE_1 0x01
#define BS_KEYCODE_2 0x02
#define BS_KEYCODE_3 0x04
#define BS_KEYCODE_4 0x08 
#define BS_KEYCODE_5 0x10
#define BS_KEYCODE_6 0x20
#define BS_KEYCODE_7 0x40
#define BS_KEYCODE_8 0x80
#define BS_Released  0xA0FF
class BS818A {
  private:
    uint8_t DataPin, ClockPin;
    unsigned int BsKey;
  public:
    void InitBS818A(byte clockPin,byte dataPin);
    int getButtonCode(void);
    boolean PressBsButton(unsigned int button);
};
#endif
