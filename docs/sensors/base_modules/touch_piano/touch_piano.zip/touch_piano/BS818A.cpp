#include"BS818A.h"

void BS818A::InitBS818A( byte dataPin, byte clockPin) {
  DataPin = dataPin;
  ClockPin = clockPin;
  pinMode(ClockPin, OUTPUT);
  digitalWrite(ClockPin, HIGH);
  pinMode(DataPin , INPUT_PULLUP);
  delay(100);
}
int BS818A::getButtonCode() {
  unsigned int DATA = 0;
  //pinMode(DataPin , OUTPUT);
  //digitalWrite(DataPin, HIGH);
  //delayMicroseconds(20);
  //digitalWrite(DataPin, LOW);
  //delayMicroseconds(20);
  //pinMode(ClockPin, OUTPUT);

  for (int i = 0; i < 16; i++)
  {
    digitalWrite(ClockPin, LOW);
    delayMicroseconds(10);
    digitalWrite(ClockPin, HIGH);
    delayMicroseconds(10);
    DATA |= digitalRead(DataPin) << i;
  }
  delay(6);
  return DATA & 0xFFFF;
}
boolean BS818A::PressBsButton(unsigned int button) {
  BsKey = getButtonCode();

  if (BsKey != BS_Released) {
    //Serial.println(BsKey, HEX);
    if ((BsKey & button) == button)
      return false;  // if bit set 1 is not button pressed
    else
      return true;
  }
  return false;
}
