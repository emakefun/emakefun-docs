import machine
from five_line_tracker_v3 import FiveLineTrackerV3

i2c = machine.I2C(0, sda=21, scl=22)
five_line_tracker = FiveLineTrackerV3(i2c, i2c_address=0x50)

# 设置传感器探头0 ~ 4的高电平阈值，当探头模拟值高于该阈值时该路的数字值由0变为1
five_line_tracker.high_thresholds = (450, 400, 410, 400, 430)

# 设置传感器探头0 ~ 4的低电平阈值，当探头模拟值低于该阈值时该路的数字值由1变为0
five_line_tracker.low_thresholds = (320, 330, 350, 310, 300)

while True:
    print('digital_values:', five_line_tracker.digital_value(0),
          five_line_tracker.digital_value(1),
          five_line_tracker.digital_value(2),
          five_line_tracker.digital_value(3),
          five_line_tracker.digital_value(4))
