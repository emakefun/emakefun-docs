from temperature_sensor_nl50 import TemperatureSensorNl50
import time


temperature_sensor_nl50 = TemperatureSensorNl50(26)


while True:
    temperature = temperature_sensor_nl50.get_temperature()
    print(f"The current temperature is: {temperature:.2f}")
    time.sleep(0.5)
