from machine import ADC


class TemperatureSensorNl50:
    def __init__(self, analog_pin) -> None:
        self._adc = ADC(analog_pin)
        self._adc.atten(ADC.ATTN_11DB)
        self._adc.width(ADC.WIDTH_10BIT)

    def get_temperature(self):
        return 100 * (self._adc.read() * 3.3 / 1023) - 50
