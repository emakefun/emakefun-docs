var searchData=
[
  ['initialize_0',['Initialize',['../classemakefun_1_1_i2c_device.html#ab6a4d05c0861cfe593f0da272fa34673',1,'emakefun::I2cDevice']]]
];
