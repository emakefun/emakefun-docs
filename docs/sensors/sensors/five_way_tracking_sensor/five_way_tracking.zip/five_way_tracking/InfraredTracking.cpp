#include "InfraredTracking.h"

InfraredTracking::InfraredTracking()
{
    Wire.begin();
    BOARD_ADDR = 0x50;
}

InfraredTracking::InfraredTracking(uint8_t addr)
{
    Wire.begin();
    BOARD_ADDR = addr;
}

void InfraredTracking::WriteRegWord(uint8_t reg, uint8_t *array)
{
    Wire.beginTransmission(BOARD_ADDR);
    Wire.write(reg);
    Wire.write(array[0]);
    Wire.write(array[1]);    
    Wire.endTransmission(); 
}

int InfraredTracking::ReadDataArray(uint8_t reg, uint8_t *array, uint8_t len)
{
    int result = 0;
    Wire.beginTransmission(BOARD_ADDR);
    Wire.write(reg);
    Wire.endTransmission();
    Wire.requestFrom(BOARD_ADDR, len);
    while (Wire.available()) {
        if (result >= len) {
            return -1;
        }
        array[result] = Wire.read();
        result++;
    }    
}

void InfraredTracking::Set_Threshold(uint16_t threshold)
{
    uint8_t array[2];
    array[0] = threshold & 0xFF;
    array[1] = (threshold >> 8) & 0xFF;
    WriteRegWord(INFRARED_THRESHOLD_REG, array);
}

uint16_t InfraredTracking::Get_Threshold()
{
    uint8_t array[2], result;
    result = ReadDataArray(INFRARED_THRESHOLD_REG, array, INFRARED_DATA_WIDTH);
    if (result == -1) {
        return -1;
    }
    Threshold = (array[0] & 0xFF) | ((array[1] & 0xFF) << 8);
    return Threshold;
}

uint8_t InfraredTracking::Get_State()
{
    uint8_t result;
    result = ReadDataArray(INFRARED_DIGITAL_REG, &state, 1);
    if (result == -1) {
        return -1;
    }
    return state;    
}

boolean InfraredTracking::Read_FIFO()
{
    uint8_t result;
    result = ReadDataArray(INFRARED_ANALOG_REG, FIFO, INFRARED_FIFO_LENGTH);  
    if (result == -1) {
        return false;
    }  
    return true;
}

void InfraredTracking::flush()
{
    Get_Threshold();
    Get_State();
    Read_FIFO();
    INF_1 = (FIFO[0] & 0xFF) | ((FIFO[1] & 0xFF) << 8 );
    INF_2 = (FIFO[2] & 0xFF) | ((FIFO[3] & 0xFF) << 8 );
    INF_3 = (FIFO[4] & 0xFF) | ((FIFO[5] & 0xFF) << 8 );
    INF_4 = (FIFO[6] & 0xFF) | ((FIFO[7] & 0xFF) << 8 );
    INF_5 = (FIFO[8] & 0xFF) | ((FIFO[9] & 0xFF) << 8 );
}

InfraredTracking::~InfraredTracking()
{
}
