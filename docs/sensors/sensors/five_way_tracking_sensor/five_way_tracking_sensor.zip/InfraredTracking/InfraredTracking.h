#ifndef INFRAREDTRACKING_H
#define INFRAREDTRACKING_H

#include <Arduino.h>
#include <stdint.h>
#include <Wire.h>

/************************************
** 阈值数据：0.5cm ~ 4.5cm (精度0.5cm) 
** 0.5cm 对应 90，4.5cm 对应750
************************************/
const uint16_t threshold_data[] = {90, 100, 110, 180, 350, 500, 550, 700, 800};

#define INFRARED_I2C_ADDR           0x50
#define INFRARED_THRESHOLD_REG      0x00
#define INFRARED_ANALOG_REG         0x01
#define INFRARED_DIGITAL_REG        0x02
#define INFRARED_DATA_WIDTH         0x02
#define INFRARED_FIFO_LENGTH        0x0A

class InfraredTracking 
{
    private:
        uint8_t FIFO[0x0A], BOARD_ADDR;
        void WriteRegWord(uint8_t reg, uint8_t *array);
        int ReadDataArray(uint8_t reg, uint8_t *array, uint8_t len);

    public: 
        uint8_t state;  
        uint16_t INF_1, INF_2, INF_3, INF_4, INF_5, Threshold;     
        InfraredTracking();
        InfraredTracking(uint8_t addr);
        void SetThreshold(uint16_t threshold);
        void SetHigh(double high);
        uint16_t GetThreshold();
        uint8_t GetState();
        boolean ReadFIFO();
        void flush();
        ~InfraredTracking();
};

#endif
