#include "InfraredTracking.h"

InfraredTracking::InfraredTracking()
{
    Wire.begin();
    BOARD_ADDR = 0x50;
}

InfraredTracking::InfraredTracking(uint8_t addr)
{
    Wire.begin();
    BOARD_ADDR = addr;
}

void InfraredTracking::WriteRegWord(uint8_t reg, uint8_t *array)
{
    Wire.beginTransmission(BOARD_ADDR);
    Wire.write(reg);
    Wire.write(array[0]);
    Wire.write(array[1]);    
    Wire.endTransmission(); 
}

int InfraredTracking::ReadDataArray(uint8_t reg, uint8_t *array, uint8_t len)
{
    int result = 0;
    Wire.beginTransmission(BOARD_ADDR);
    Wire.write(reg);
    Wire.endTransmission();
    Wire.requestFrom(BOARD_ADDR, len);
    while (Wire.available()) {
        if (result >= len) {
            return -1;
        }
        array[result] = Wire.read();
        result++;
    }    
}

void InfraredTracking::Set_Threshold(uint16_t threshold)
{
    uint8_t array[2];
    array[0] = threshold & 0xFF;
    array[1] = (threshold >> 8) & 0xFF;
    WriteRegWord(INFRARED_THRESHOLD_REG, array);
}

void InfraredTracking::Set_High(double high)
{
    int high_val = (int)(high * 10);
    uint16_t data;
    uint8_t array[2];
    if (high_val > 0 && high_val < 5) {
        data = threshold_data[0];
    }else if (high_val >= 5 && high_val < 10) {
        data = threshold_data[1];
    }else if (high_val >= 10 && high_val < 15) {
        data = threshold_data[2];
    }else if (high_val >= 15 && high_val < 20) {
        data = threshold_data[3];
    }else if (high_val >= 20 && high_val < 25) {
        data = threshold_data[4];
    }else if (high_val >= 25 && high_val < 30) {
        data = threshold_data[5];
    }else if (high_val >= 30 && high_val < 35) {
        data = threshold_data[6];
    }else if (high_val >= 35 && high_val < 40) {
        data = threshold_data[7];
    }else if (high_val >= 40 && high_val <= 45) {
        data = threshold_data[8];
    }else {
        data = 0;
    }
    array[0] = data & 0xFF;
    array[1] = (data >> 8) & 0xFF;
    WriteRegWord(INFRARED_THRESHOLD_REG, array);
}

uint16_t InfraredTracking::Get_Threshold()
{
    uint8_t array[2], result;
    result = ReadDataArray(INFRARED_THRESHOLD_REG, array, INFRARED_DATA_WIDTH);
    if (result == -1) {
        return -1;
    }
    Threshold = (array[0] & 0xFF) | ((array[1] & 0xFF) << 8);
    return Threshold;
}

uint8_t InfraredTracking::Get_State()
{
    uint8_t result;
    result = ReadDataArray(INFRARED_DIGITAL_REG, &state, 1);
    if (result == -1) {
        return -1;
    }
    return state;    
}

boolean InfraredTracking::Read_FIFO()
{
    uint8_t result;
    result = ReadDataArray(INFRARED_ANALOG_REG, FIFO, INFRARED_FIFO_LENGTH);  
    if (result == -1) {
        return false;
    }  
    return true;
}

void InfraredTracking::flush()
{
    Get_Threshold();
    Get_State();
    Read_FIFO();
    INF_1 = (FIFO[0] & 0xFF) | ((FIFO[1] & 0xFF) << 8 );
    INF_2 = (FIFO[2] & 0xFF) | ((FIFO[3] & 0xFF) << 8 );
    INF_3 = (FIFO[4] & 0xFF) | ((FIFO[5] & 0xFF) << 8 );
    INF_4 = (FIFO[6] & 0xFF) | ((FIFO[7] & 0xFF) << 8 );
    INF_5 = (FIFO[8] & 0xFF) | ((FIFO[9] & 0xFF) << 8 );
}

InfraredTracking::~InfraredTracking()
{
}
