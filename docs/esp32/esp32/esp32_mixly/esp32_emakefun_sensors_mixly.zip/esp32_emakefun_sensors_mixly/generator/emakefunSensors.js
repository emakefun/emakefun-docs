
'use strict';
goog.provide('Blockly.Arduino.Mqtt');
goog.require('Blockly.Arduino');

Blockly.Arduino.forBlock['emakefun_get_esp32_mac'] = function() {
    Blockly.Arduino.definitions_['include_ESP32_PS3'] = '#include <Ps3Controller.h>\n';
    Blockly.Arduino.setups_['setup_esp32_ps3'] = 'Ps3.begin();\n';
    var code = "Ps3.getAddress()";
  return [code, Blockly.Arduino.ORDER_ATOMIC];
};

Blockly.Arduino.forBlock['emakefun_esp32_isConnect'] = function() {
    Blockly.Arduino.definitions_['include_ESP32_PS3'] = '#include <Ps3Controller.h>\n';
    Blockly.Arduino.setups_['setup_esp32_ps3'] = 'Ps3.begin();\n';
    var code = "Ps3.isConnected()";
    return [code, Blockly.Arduino.ORDER_ATOMIC];
};

Blockly.Arduino.forBlock['emakefun_esp32_get_button'] = function() {
  Blockly.Arduino.definitions_['include_ESP32_PS3'] = '#include <Ps3Controller.h>\n';
  Blockly.Arduino.setups_['setup_esp32_ps3'] = 'Ps3.begin();\n';
  var button = this.getFieldValue('button');
  var status = this.getFieldValue('status');
  var code = "";
  if (status == "analog_changed") {
    if (button == "start" || button == "select" || button == "l3" || button == "r3" ) {
      code = "";
    }else {
      code = "Ps3.event.analog_changed.button." + button;
    }
  } else {
    code = "Ps3.event." + status + "." + button;
  }
  return [code, Blockly.Arduino.ORDER_ATOMIC];
};

Blockly.Arduino.forBlock['emakefun_esp32_get_rock_analog'] = function() {
  Blockly.Arduino.definitions_['include_ESP32_PS3'] = '#include <Ps3Controller.h>\n';
  Blockly.Arduino.setups_['setup_esp32_ps3'] = 'Ps3.begin();\n';
  var ps3Rock = this.getFieldValue('ps3Rock');
  var code = ps3Rock;
  return [code, Blockly.Arduino.ORDER_ATOMIC];
};

Blockly.Arduino.forBlock['emakefun_esp32_get_battey_status'] = function() {
  Blockly.Arduino.definitions_['include_ESP32_PS3'] = '#include <Ps3Controller.h>\n';
  Blockly.Arduino.setups_['setup_esp32_ps3'] = 'Ps3.begin();\n';
  // var ps3Rock = this.getFieldValue('ps3Rock');
  var code = Ps3.data.status.battery;
  return [code, Blockly.Arduino.ORDER_ATOMIC];
};

Blockly.Arduino.forBlock['emakefun_esp32_get_battey_status'] = function() {
  Blockly.Arduino.definitions_['include_ESP32_PS3'] = '#include <Ps3Controller.h>\n';
  Blockly.Arduino.setups_['setup_esp32_ps3'] = 'Ps3.begin();\n';
  var ps3Battery = this.getFieldValue('ps3Battery');
  var code = ps3Battery;
  return [code, Blockly.Arduino.ORDER_ATOMIC];
};

Blockly.Arduino.forBlock['emakefun_esp32_PS3_set_player'] = function() {
  Blockly.Arduino.definitions_['include_ESP32_PS3'] = '#include <Ps3Controller.h>\n';
  Blockly.Arduino.setups_['setup_esp32_ps3'] = 'Ps3.begin();\n';
  var emakefun_player = Blockly.Arduino.valueToCode(this, 'emakefun_player', Blockly.Arduino.ORDER_ATOMIC);
  var code = `Ps3.setPlayer(${emakefun_player});\n`;
  return code;
};

 // 语音识别设置唤醒词
 Blockly.Arduino.forBlock['nulllab_VoiceRecognition_init_V2'] = function(){
	Blockly.Arduino.definitions_['VoiceRecognition_v2'] = '#include <speech_recognizer.h>\n';
	var voiceRecognitionV2 = this.getFieldValue('nulllab_VoiceRecognition_V2');
	var nulllabModeV2 = this.getFieldValue('nulllab_mode_V2');
	Blockly.Arduino.definitions_['VoiceRecognition_v2_init_' + voiceRecognitionV2] = 'emakefun::SpeechRecognizer ' + voiceRecognitionV2 + '(emakefun::SpeechRecognizer::kDefaultI2cAddress);\n';
	Blockly.Arduino.setups_['Setup' + voiceRecognitionV2] = voiceRecognitionV2 + '.Initialize();\n';
	Blockly.Arduino.setups_['SetTrigger_' + voiceRecognitionV2] = voiceRecognitionV2 + '.SetRecognitionMode(emakefun::SpeechRecognizer::' + nulllabModeV2 + ');\n';
	return '';
 }

Blockly.Arduino.forBlock['nulllab_VoiceRecognition_Content_V2'] = function(){
	Blockly.Arduino.definitions_['VoiceRecognition_v2'] = '#include <speech_recognizer.h>\n';
	var voiceRecognitionV2 = this.getFieldValue('nulllab_VoiceRecognition_V2');
	var nulllab_Key_V2 = Blockly.Arduino.valueToCode(this,'nulllab_Key_V2',Blockly.Arduino.ORDER_ATOMIC);
	var nulllab_content_V2 = Blockly.Arduino.valueToCode(this,'nulllab_content_V2',Blockly.Arduino.ORDER_ATOMIC);
	Blockly.Arduino.setups_['VoiceRecognition_content' + voiceRecognitionV2 + '_' + nulllab_Key_V2] = voiceRecognitionV2 + '.AddKeyword(' + nulllab_Key_V2 + ', F(' + nulllab_content_V2 + '));\n';
	return '';
 }

 Blockly.Arduino.forBlock['nulllab_VoiceRecognition_time_V2'] = function(){
	Blockly.Arduino.definitions_['VoiceRecognition_v2'] = '#include <speech_recognizer.h>\n';
	var voiceRecognitionV2 = this.getFieldValue('nulllab_VoiceRecognition_V2');
	var nulllab_time_V2 = Blockly.Arduino.valueToCode(this,'nulllab_time_V2',Blockly.Arduino.ORDER_ATOMIC);
	Blockly.Arduino.setups_['VoiceRecognition_time' + voiceRecognitionV2 + '_' + nulllab_time_V2] = voiceRecognitionV2 + '.SetTimeout(' + nulllab_time_V2 + ');\n';
	return '';
 }

 Blockly.Arduino.forBlock['speech_recognizer_event'] = function(){
	Blockly.Arduino.definitions_['VoiceRecognition_v2'] = '#include <speech_recognizer.h>\n';
	var voiceRecognitionV2 = this.getFieldValue('nulllab_VoiceRecognition_V2');
	var code = `${voiceRecognitionV2}.Recognize()`;
	return [code, Blockly.Arduino.ORDER_ATOMIC];
 }

//  var speechVal = 0;
 //语音合成播报开始
Blockly.Arduino.forBlock['nulllab_speech_synthesisStart'] = function(){
	var voice = this.getFieldValue('nulllab_voice');
	var voiceSpeed = this.getFieldValue('nulllab_voiceSpeed');
	var nulllab_speech = this.getFieldValue('nulllab_speech');
	var content = Blockly.Arduino.valueToCode(this, 'nulllab_content', Blockly.Arduino.ORDER_ATOMIC);
	Blockly.Arduino.definitions_['speech_synthesisCache'] = '#include <tts.h>\n';
	Blockly.Arduino.definitions_['synthesisCache_' + nulllab_speech] = 'emakefun::Tts ' + nulllab_speech + '(emakefun::Tts::kDefaultI2cAddress);\n';
	Blockly.Arduino.setups_['Setup' + nulllab_speech] = nulllab_speech + '.Initialize();\n';
	var code = `${nulllab_speech}.Play(String("[v${voice}][s${voiceSpeed}]") + String(${content}));\n`;
	// speechVal ++;
	return code;
 }

//语音合成缓存内容
Blockly.Arduino.forBlock['nulllab_speech_synthesisCache'] = function(){
	var voice = this.getFieldValue('nulllab_voice');
	var voiceSpeed = this.getFieldValue('nulllab_voiceSpeed');
	var nulllab_speech = this.getFieldValue('nulllab_speech');
	var content = Blockly.Arduino.valueToCode(this, 'nulllab_content', Blockly.Arduino.ORDER_ATOMIC);
	var nulllab_index = Blockly.Arduino.valueToCode(this, 'nulllab_index', Blockly.Arduino.ORDER_ATOMIC);
	Blockly.Arduino.definitions_['speech_synthesisCache'] = '#include <tts.h>\n';
	Blockly.Arduino.definitions_['synthesisCache_' + nulllab_speech] = 'emakefun::Tts ' + nulllab_speech + '(emakefun::Tts::kDefaultI2cAddress);\n';
	Blockly.Arduino.setups_['Setup' + nulllab_speech] = nulllab_speech + '.Initialize();\n';
	var code = `${nulllab_speech}.PushTextToCache(String("[v${voice}][s${voiceSpeed}]") + String(${content}), ${nulllab_index});\n`;
	return code;
 }

Blockly.Arduino.forBlock['nulllab_speech_cplay'] = function(){
	var nulllab_speech = this.getFieldValue('nulllab_speech');
	var freq = Blockly.Arduino.valueToCode(this, 'nulllab_freq', Blockly.Arduino.ORDER_ATOMIC);
	Blockly.Arduino.definitions_['speech_synthesisCache'] = '#include <tts.h>\n';
	Blockly.Arduino.definitions_['synthesisCache_' + nulllab_speech] = 'emakefun::Tts ' + nulllab_speech + '(emakefun::Tts::kDefaultI2cAddress);\n';
	Blockly.Arduino.setups_['Setup' + nulllab_speech] = nulllab_speech + '.Initialize();\n';
	// Blockly.Arduino.setups_['SetTime'] = 'ld3320_config_time('+time+');\n';
	var code = `${nulllab_speech}.PlayFromCache();\n`;
	return code;
 }

//使用帮助
Blockly.Arduino.forBlock['emakefun_ps3_help'] = function() {
  Blockly.Arduino.setups_['emakefun_ps3_help'] = 'Serial.begin(115200);\nSerial.println("help url: https://docs.emakefun.com/esp32/ps3_esp32/");';
  return "";
};
