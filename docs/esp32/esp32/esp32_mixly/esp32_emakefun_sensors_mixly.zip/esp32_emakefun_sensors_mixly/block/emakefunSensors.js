(() => {

    'use strict';
    goog.require('path');
    goog.require('Blockly.Blocks');

    const mediaDirPath = path.join(document.currentScript.src, '../../media/');

    //设置服务器地址与端口号
    Blockly.Blocks.emakefun_get_esp32_mac = {
        init: function () {
            this.setColour(133);
            this.appendDummyInput("")
                .appendField(Blockly.Msg.EMAKEFUN_GET_ESP32_MAC);
                this.setOutput(true, String);
        }
    };

    // 是否连接
    Blockly.Blocks.emakefun_esp32_isConnect = {
        init: function () {
            this.setColour(133);
            this.appendDummyInput("")
                .appendField(Blockly.Msg.EMAKEFUN_GET_ESP32_IS_CONNECT);
                this.setOutput(true, Boolean);
        }
    };

    Blockly.Blocks.emakefun_esp32_get_button = {
        init: function () {
            this.setColour(133);
            this.appendDummyInput("")
                .appendField(Blockly.Msg.EMAKEFUN_ESP32_PS3_BUTTON)
                .appendField(new Blockly.FieldDropdown(
                   [["x键", "cross"],
                    ["三角形键", "triangle"],
                    ["圆形键", "circle"],
                    ["正方形键", "square"],
                    ["SELECT键", "select"],
                    ["START键", "start"],
                    ["方向键上", "up"],
                    ["方向键下", "down"],
                    ["方向键左", "left"],
                    ["方向键右", "right"],
                    ["左侧1", "l1"],
                    ["左侧2", "l2"],
                    ["左侧3", "l3"],
                    ["右侧1", "r1"],
                    ["右侧2", "r2"],
                    ["右侧3", "r3"]]
                ), 'button')
                .appendField(Blockly.Msg.EMAKEFUN_ESP32_PS3_BUTTON_STATUS)
                .appendField(new Blockly.FieldDropdown(
                    [["按下", "button_down"],
                    ["松开", "button_up"],
                    ["改变", "analog_changed"]]
                ), 'status')
                this.setOutput(true, Boolean);
        }
    };

    Blockly.Blocks.emakefun_esp32_get_rock_analog = {
        init: function () {
            this.setColour(133);
            this.appendDummyInput("")
                .appendField(Blockly.Msg.EMAKEFUN_GET_PS3_ROCK_VALUE)
                .appendField(new Blockly.FieldDropdown(
                   [ ["左侧X值", "Ps3.data.analog.stick.lx"],
                    ["左侧Y值", "Ps3.data.analog.stick.ly"],
                    ["右侧X值", "Ps3.data.analog.stick.rx"],
                    ["右侧Y值", "Ps3.data.analog.stick.ry"]]
                ), 'ps3Rock')
                this.setOutput(true, Number)
        }
    };

    Blockly.Blocks.emakefun_esp32_get_battey_status = {
        init: function () {
            this.setColour(133);
            this.appendDummyInput("")
                .appendField(Blockly.Msg.EMAKEFUN_GET_PS3_BATTERY_STATUS)
                this.setOutput(true, Number)
        }
    };
    
    Blockly.Blocks.emakefun_esp32_PS3_battey_status = {
        init: function () {
            this.setColour(133);
            this.appendDummyInput("")
                .appendField(Blockly.Msg.EMAKEFUN_PS3_BATTERY_STATUS)
                .appendField(new Blockly.FieldDropdown(
                    [ ["充电中", "ps3_status_battery_charging"],
                     ["满电", "ps3_status_battery_full"],
                     ["高电量", "ps3_status_battery_high"],
                     ["低电量", "ps3_status_battery_low"],
                     ["电量已用尽", "ps3_status_battery_dying"],
                     ["关机", "ps3_status_battery_shutdown"],
                    ]
                 ), 'ps3Battery')
                this.setOutput(true, Number)
        }
    };

    Blockly.Blocks.emakefun_esp32_PS3_set_player = {
        init: function () {
            this.setColour(133);
            this.appendDummyInput("")
                .appendField(Blockly.Msg.EMAKEFUN_GET_PS3_SET_PLAYER)
            this.appendValueInput("emakefun_player", Number)
        this.setPreviousStatement(true, null);
        this.setNextStatement(true, null);
        this.setInputsInline(true);
        this.setTooltip('');
        }
    };



    // nulllab_VoiceRecognition_init_V2
Blockly.Blocks.nulllab_VoiceRecognition_init_V2 = {
    init: function () {
      this.setColour(150);
      this.appendDummyInput("")
        .appendField(Blockly.Msg.EM_VOICERECOGNITION_INIT_V2)
        .appendField(new Blockly.FieldTextInput('myVoiceRecognitionV2'), 'nulllab_VoiceRecognition_V2')
        .appendField(Blockly.Msg.EM_VOICERECOGNITION_MODE)
        .appendField(new Blockly.FieldDropdown(
          [
            [Blockly.Msg.EM_VOICERECOGNITION_MODEA, 'kRecognitionAuto'],
            [Blockly.Msg.EM_VOICERECOGNITION_MODEB, 'kButtonTrigger'],
            [Blockly.Msg.EM_VOICERECOGNITION_MODEC, 'kKeywordTrigger'],
            [Blockly.Msg.EM_VOICERECOGNITION_MODED, 'kKeywordOrButtonTrigger']
          ]), "nulllab_mode_V2")
      this.setPreviousStatement(true, null);
      this.setNextStatement(true, null);
      this.setTooltip('');
    }
  }
  
    //语音识别设置词条和编号
    Blockly.Blocks.nulllab_VoiceRecognition_Content_V2 = {
      init: function () {
        this.setColour(150);
        this.appendDummyInput("")
        .appendField(Blockly.Msg.EM_VOICERECOGNITION_V2)
        .appendField(new Blockly.FieldTextInput('myVoiceRecognitionV2'), 'nulllab_VoiceRecognition_V2')
          //.appendField(Blockly.INITIALIZE_MATRIX_KEYBOARD)
        this.appendValueInput("nulllab_Key_V2", Number)
          .appendField(Blockly.Msg.EM_VOICERECOGNITION_KEY)
          .setCheck(Number);
        this.appendValueInput("nulllab_content_V2", String)
          .appendField(Blockly.Msg.EM_VOICERECOGNITION_CONTENT)
        this.setPreviousStatement(true, null);
        this.setInputsInline(true);
        this.setNextStatement(true, null);
      }
    };
  
      //语音识别设置唤醒词
      Blockly.Blocks.nulllab_VoiceRecognition_time_V2 = {
        init: function () {
          this.setColour(150);
          this.appendDummyInput("")
          .appendField(Blockly.Msg.EM_VOICERECOGNITION_V2)
          .appendField(new Blockly.FieldTextInput('myVoiceRecognitionV2'), 'nulllab_VoiceRecognition_V2')
          .appendField(Blockly.Msg.EM_VOICERECOGNITION_TIME);
          this.appendValueInput("nulllab_time_V2", Number)
            .setCheck(Number)
            .setAlign(Blockly.Msg.EM_ALIGN_RIGHT);
          this.setInputsInline(true);
          this.setPreviousStatement(true, null);
          this.setNextStatement(true, null);
          this.setTooltip('');
        }
      };
  
    Blockly.Blocks.speech_recognizer_event = {
      init: function () {
        this.setColour(150);
        this.appendDummyInput("")
        .appendField(Blockly.Msg.EM_VOICERECOGNITION_V2)
        .appendField(new Blockly.FieldTextInput('myVoiceRecognitionV2'), 'nulllab_VoiceRecognition_V2')
          .appendField(Blockly.Msg.EM_VOICERECOGNITION_NUMBER)
        this.setOutput(true, Number);
        this.setTooltip(true);
      }
    };
      
    // 开始语音合成并播放
  Blockly.Blocks.nulllab_speech_synthesisStart = {
    init: function () {
      this.setColour(180);
      this.appendDummyInput("")
      .appendField(Blockly.Msg.EM_SPEECH)
      .appendField(new Blockly.FieldTextInput('mySpeechSynthesis'), 'nulllab_speech')
        .appendField(Blockly.Msg.EM_SPEECH_START)
        .appendField(new Blockly.FieldDropdown(
          [
            ['5', '5'],
            ['0', '0'],
            ['1', '1'],
            ['2', '2'],
            ['3', '3'],
            ['4', '4'],
            ['6', '6'],
            ['7', '7'],
            ['8', '8'],
            ['9', '9'],
            ['10', '10'],
          ]), "nulllab_voice")
        // .setCheck(Number)
        .appendField(Blockly.Msg.EM_SPEECH_VOICESPEED)
        .appendField(new Blockly.FieldDropdown(
          [
            ['5', '5'],
            ['0', '0'],
            ['1', '1'],
            ['2', '2'],
            ['3', '3'],
            ['4', '4'],
            ['6', '6'],
            ['7', '7'],
            ['8', '8'],
            ['9', '9'],
            ['10', '10'],
          ]), "nulllab_voiceSpeed")
        // .setCheck(Number)
        this.appendValueInput("nulllab_content", String)
        .appendField(Blockly.Msg.EM_SPEECH_VOICECONTENT)
        // .setAlign(Blockly.ALIGN_RIGHT);
      this.setInputsInline(true);
      this.setPreviousStatement(true, null);
      this.setNextStatement(true, null);
      this.setTooltip('');
    }
  };
  
    // 把命令帧缓存
    Blockly.Blocks.nulllab_speech_synthesisCache = {
      init: function () {
        this.setColour(180);
        this.appendDummyInput("")
        .appendField(Blockly.Msg.EM_SPEECH)
        .appendField(new Blockly.FieldTextInput('mySpeechSynthesis'), 'nulllab_speech')
          .appendField(Blockly.Msg.EM_SPEECH_STARTCACHE)
          .appendField(new Blockly.FieldDropdown(
            [
              ['5', '5'],
              ['0', '0'],
              ['1', '1'],
              ['2', '2'],
              ['3', '3'],
              ['4', '4'],
              ['6', '6'],
              ['7', '7'],
              ['8', '8'],
              ['9', '9'],
              ['10', '10'],
            ]), "nulllab_voice")
          // .setCheck(Number)
          .appendField(Blockly.Msg.EM_SPEECH_VOICESPEED)
          .appendField(new Blockly.FieldDropdown(
            [
              ['5', '5'],
              ['0', '0'],
              ['1', '1'],
              ['2', '2'],
              ['3', '3'],
              ['4', '4'],
              ['6', '6'],
              ['7', '7'],
              ['8', '8'],
              ['9', '9'],
              ['10', '10'],
            ]), "nulllab_voiceSpeed")
          // .setCheck(Number)
          this.appendValueInput("nulllab_content", String)
          .appendField(Blockly.Msg.EM_SPEECH_VOICECACHECONTENT)
          this.appendValueInput("nulllab_index", Number)
          .appendField(Blockly.Msg.EM_SPEECH_VOICECACHEINDEX)
          // .setAlign(Blockly.ALIGN_RIGHT);
        this.setInputsInline(true);
        this.setPreviousStatement(true, null);
        this.setNextStatement(true, null);
        this.setTooltip('');
      }
    };
  
  //播报次数
  Blockly.Blocks.nulllab_speech_cplay={
    init:function(){
      this.setColour(180);
      this.appendDummyInput("")
      .appendField(Blockly.Msg.EM_SPEECH)
        .appendField(new Blockly.FieldTextInput('mySpeechSynthesis'), 'nulllab_speech')
      this.appendValueInput("nulllab_freq", Number)
          .appendField(Blockly.Msg.EM_SPEED_CPLAY)
      this.setInputsInline(true);
      // this.setOutput(false);
      this.setPreviousStatement(true, null);
      this.setNextStatement(true, null);
      this.setTooltip('');
    }
  }

    //使用帮助
    Blockly.Blocks.emakefun_ps3_help = {
        init: function () {
            this.setColour(60);
            this.appendValueInput("ps3_help")
                .setCheck(null)
                .appendField(Blockly.Msg.emakefun_Mixly_ps3_help);
                this.setTooltip(Blockly.Msg.MQTT_TEST_TOOLTIP);
            this.setHelpUrl(Blockly.Msg.emakefun_ps3_helpurl);
        }
    };

})();